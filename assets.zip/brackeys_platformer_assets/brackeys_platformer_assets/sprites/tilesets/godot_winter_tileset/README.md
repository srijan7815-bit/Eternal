# Winter Pixel Landscape — Godot 4

A ready-to-open Godot 4 starter project using the six supplied 384×216 pixel-art images. The source artwork is a set of transparent/opaque panorama layers, not a grid of independently repeatable terrain tiles; the project therefore imports them as a layered parallax scene (the most faithful, immediately usable setup). `reference_composite.png` is the supplied all-in-one preview.

## Open and run
1. Extract this folder.
2. In Godot 4, choose **Import** and select `project.godot`.
3. Run `WinterLandscape.tscn` (F6), or press F6 from that scene.

The project uses a 384×216 logical viewport, nearest-neighbor filtering, and parallax speeds that can be adjusted on each `Parallax2D` node. The artwork is not horizontally seamless, so repeat is intentionally disabled. For a real grid TileMap, these panoramas would need to be cut/redrawn into seamless cells; arbitrary slicing would create broken edges.

## Layers
- `cloudy_sky.png` — opaque sky/background
- `mountains.png` — transparent mountain layer
- `snowy_firs.png` — detailed firs
- `dark_fir_silhouette.png` — dark foreground tree line
- `snow_ground.png` — snow strip
- `reference_composite.png` — original assembled reference
